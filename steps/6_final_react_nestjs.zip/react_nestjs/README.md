## 0. Prerequisites
 - Run MySQL Docker container
 - Use Node.js version 22.14.0 (nvm use 22.14.0)

## 1. Run Backend
 - cd backend
 - npm install
 - npm run start:dev

## 2. Run Frontend
 - cd frontend
 - npm install
 - npm run dev
