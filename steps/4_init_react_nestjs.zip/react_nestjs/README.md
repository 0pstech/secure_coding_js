## 0. prerequisite
 - run mysql docker
 - nvm use 22.14.0

## 1. run backend
 - cd backend
 - npm install
 - npm run start:dev

## 2. run frontend
 - cd frontend
 - npm install
 - npm run dev
