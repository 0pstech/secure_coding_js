# HOW TO
## 0. requirement
 - install burp suite and set proxy
 - run burp suite browser

## 1. run DB server
 - cd mysql
 - docker-compose up --build -d
 - docker ps

## 2. run server
 - nvm use 22.14.0
 - cd vanilla_express
 - npm install 
 - npm run dev

## 3. connect server
 - http://localhost:3000

